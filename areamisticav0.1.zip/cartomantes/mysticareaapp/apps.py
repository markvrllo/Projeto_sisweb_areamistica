from django.apps import AppConfig


class MysticareaappConfig(AppConfig):
    name = 'mysticareaapp'
